Put your project card image headers in this folder.
